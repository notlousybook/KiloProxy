"""Kilo Proxy - OpenAI-compatible API proxy for Kilo."""

__version__ = "1.0.0"
