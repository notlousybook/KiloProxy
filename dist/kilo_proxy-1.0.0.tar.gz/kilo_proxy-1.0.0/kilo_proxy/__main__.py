"""Entry point for python -m kilo_proxy."""

from kilo_proxy.cli import app

if __name__ == "__main__":
    app()
